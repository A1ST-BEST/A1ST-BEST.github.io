<?php
$host = 'localhost';
$username = 'id20583432_rhrh';
$password = 'Raja19492000!';
$dbname = 'id20583432_rh';
$conn = mysqli_connect($host, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

    $image = 'employee.png';


mysqli_close($conn);
?>

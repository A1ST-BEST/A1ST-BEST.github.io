<?php
session_start();
require_once("connexiondb.php");

$login = $_POST['email'];
$mt = $_POST['motdepasse'];

$requete = "SELECT * FROM employes WHERE email='$login' AND motdepasse='$mt'";
$resultat = $pdo->query($requete);

$requete2 = "SELECT * FROM rh WHERE email='$login' AND motdepasse='$mt'";
$resultat2 = $pdo->query($requete2);

if ($user = $resultat->fetch()) {
    if ($user['etat'] == 1) {
        $_SESSION['user'] = $user;
        echo "<script>window.location='profilEmployes.php';</script>";
    } else {
        $_SESSION['erreurLogin'] = "<strong>Error!! </strong>Your account is deactivated.<br>Please contact the administrator.";
        echo "<script>window.location='connexion.php';</script>";
    }
} else if ($user = $resultat2->fetch()) {
    $_SESSION['user'] = $user;
    echo "<script>window.location='profilRH.php';</script>";
} else {
    $_SESSION['erreurLogin'] = "<strong>Error!! </strong>Incorrect email or password!";
    echo "<script>window.location='connexion.php';</script>";
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Abderrahman Youabd">
    <meta name="generator" content="Hugo 0.84.0">
    <title>registration</title>
    <link rel="icon" href="favicona1st.ico" type="image/x-icon">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/navbar-static/">
    <link rel="stylesheet" href="fichier.css">
    

    <!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:ital@1&display=swap');



p, a, span, h1, label, .form-group{
    font-family: 'Poppins', sans-serif !important;
  }

  body{
    background: url('../images/Wood.jpeg') !important;
    background-size:cover;
  }
  .inscform{
    background-color:burlywood;
    padding: 18px;
    border-radius: 20px 20px 0 0;
    border: 3px solid gray;
  }
  .image{
    width: 150px;
  }
  .form-group, label{
    color: #402F1D !important;
  }

  .container{
    margin-top: -30px !important;
  }

  .form-control{
    margin-right: 100px !important;
    margin-bottom: 10px !important;
  }
  .inscform{
    box-shadow: 0 0 20px gray !important;
    
  }

  body{
    height: 100vh;
    background-size:cover !important;
  }
  
          img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]
        {display:none !important;}

    </style>
 <link href="navbar-top.css" rel="stylesheet">
    
    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.0/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.0/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.0/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.0/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.0/assets/img/favicons/safari-pinned-tab.svg" color="#7952b3">
<link rel="icon" href="/docs/5.0/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#7952b3">

  </head>
  <body>
    <?php include('menu.php');?>
 
    
    <div class="container d-flex flex-column justify-content-center align-items-center">
    <h1 class="text-center">Sign Up</h1>
    <img src="../images/undraw_profile_pic_ic5t.svg" class="img-fluid mx-auto image" alt="Profile picture">
    
  <div class="inscform">
      
     <form class="" id="" name="" enctype="multipart/form-data" method="post" action="ajouteremployes.php">
      <div class="row">
      <div class="form-group col-md-12"> 
            <label >Photo</label>
            <input type="file" name="photo" class="form-control" id="photo" placeholder="photo">     
         </div>
      </div>  
      <div class="row">
      <div class="form-group col-md-6"> 
            <label>Email</label>
            <input type="email" name="email" class="form-control" id="email" placeholder="Email">     
         </div>
         <div class="form-group col-md-6"> 
             <label>Date of birth</label>
            <input type="date" name="date" class="form-control" id="date" placeholder="Date of birth">      
         </div>
      </div>
    <div class="row">
      <div class="form-group col-md-6">
              <label>Full Name</label>
            <input type="text" name="nom" class="form-control" id="nom" placeholder="Full Name">   
         </div>
     <div class="form-group col-md-6">
             <label>Phone N°</label>
            <input type="number" name="telephone" class="form-control" id="tel" placeholder="Phone Number">   
         </div>
         </div>
     <div class="row">
      <div class="form-group col-md-6">
              <label>Department</label>
            <input type="text" name="dep" class="form-control" id="dep" placeholder="Department">   
         </div>
     <div class="form-group col-md-6">
             <label>Position</label>
            <input type="text" name="poste" class="form-control" id="poste" placeholder="Position">   
         </div>
         </div>
     <div class="row">
      <div class="form-group col-md-6">
              <label>Password</label>
            <input type="password" name="mt" class="form-control" id="password" placeholder="Password">   
         </div>
     <div class="form-group col-md-6">
             <label>Confirm Password</label>
            <input type="password" name="confirmer le mot de passe" class="form-control" id="confirmpassword" placeholder="Re-enter Password">   
         </div>
         </div>
     
    <br>     
    <div class="row">
    <div class="form-group col-md-6">
    <input type="submit" class="btn btn-success btn-block" id="inscrire" name="submit" value="Register">
    </div>    
    </div>    
     </form> 
  </div>      
  
  </div>

<script>
      document.querySelector('#inscrire').onclick = function(){
          var password = document.querySelector('#password').value,
          confirmpassword = document.querySelector('#confirmpassword').value,
          photo = document.querySelector('#photo').value,
          email = document.querySelector('#email').value,
          date = document.querySelector('#date').value,
          nom = document.querySelector('#nom').value,
          tel = document.querySelector('#tel').value,
          dep = document.querySelector('#dep').value,
          poste = document.querySelector('#poste').value;
         if(password=="" || photo=="" || email=="" || date=="" || nom=="" || tel=="" || dep=="" || poste==""){
             alert("check that you have filled in all the fields correctly !");
             return false;
         }
         else if(password !=confirmpassword ){
             alert("password does not match try again ! ");
             return false;
         }
         else return true;
      }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>



  </body>
</html>

<?php
   try{
      $pdo= new PDO ("mysql:host=localhost;dbname=id20583432_rh","id20583432_rhrh","Raja19492000!");
   }catch(Exception $e){
      die('Connexion error :'.$e->getMessage());
   }
?>
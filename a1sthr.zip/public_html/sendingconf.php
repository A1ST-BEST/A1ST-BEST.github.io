<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Abderrahman Youabd">
    <title>Invitation email</title>
    <link rel="stylesheet" href="../pages/stylesendingconf.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" href="favicona1st.ico" type="image/x-icon">
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
      </script>
</head>
<style>
@import url('https://fonts.googleapis.com/css2?family=Abril+Fatface&family=Merriweather:ital@0;1&family=Poppins:ital@1&family=Space+Mono&display=swap');


*{
    margin: 0;
    padding: 0;
    font-family: "poppins";
}


html { 
    height: 100%;
    min-width: auto;
    min-height: 100vh;
    overflow:hidden;
  }

.container{
    width: 100%;
    height: 100%;

}


.contact {
    background:#fff;

}


.submit-form {
    background: url('../images/Wood.jpeg');
    background-size: cover;
    width: 100%;
    height: 100vh;
    align-items: center;
    justify-content: center;

}



 .third-text{
    font-size: 25px;
    top: 20px;
    left: 20px;
    padding-top: 40px;
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;

}


form {
    padding: 0 50px;
    height: 100%;
    width: 100%;
    overflow: hidden;
}

.input-none-changeable{
    height: 40px;
    width: 70%;
    margin: 30px auto;
    position: relative;
}

.input-box{
    height: 40px;
    width: 70%;
    margin: 30px auto;
    position: relative;
    

}

.input {
    width: 100%;
    height: 100%;
    background: transparent;
    border: 2px solid #fff;
    border-radius: 20px;
    outline: none;
    padding-left: 10px;
    color: #fff;
    font-size: 16px;

}

.input-none-changeable label{
    position: absolute;
    top: 50%;
    left: 10px;
    padding-left: 10px;
    transform: translateY(-50%);
    font-size: 15px;
    font-weight: 500;
    color: #fff;
}



.input-box label{
    position: absolute;
    top: 50%;
    left: 10px;
    padding-left: 10px;
    transform: translateY(-50%);
    font-size: 15px;
    font-weight: 500;
    color: #fff;
}


.input-box .input:focus ~ label, 
.input-box .input:valid ~ label{ 
    top: -3px;
    left: 10px;
    background: url('../images/Wood.jpeg');
    font-weight: 500;
    font-size: 12px;
    padding: 0px;
}

#message{
    resize: none;
    min-height: 400px;
    overflow: auto;
    align-items: right;

}

.btn{
    top: 100px;
    background: #fff;
    outline: none;
    border: none;
    border-radius: 4px;
    height: 45px;
    width: 20%;
    font-size: 16px;
    color: darkred;
    cursor: pointer;
    font-weight: 500;
    margin: 450px auto;
    display: flex;
    justify-content: center;
    align-items: center;
}

.btn:hover{
    background-color: #795C32 !important;
    box-shadow: 0 0 20px #795C32 !important;
    font-size: large;
    transform: scale(1.029);
}

  .zoom-effect {
    display: inline-block;
    overflow: hidden;
    position: relative;
  }
  
  
  .zoom-effect:hover  {
    transform: scale(1.2);
  }
  



  .breadcrumb {
    background-color: gray;
    padding: 10px;
    margin-bottom: 10px;
    font-size: 14px;
    position: absolute;
    display: flex;
    border-radius: 20px;
    animation: slideTop 1s ease forwards;
    opacity: 0;
    animation-delay: .4s;
    background: transparent/*#402F1D*/;
    backdrop-filter: blur(25px);
    bottom: 860px;
    left: 0px;
    min-width:fit-content;
  }
  
  .breadcrumb a {
    color: black;
    text-decoration: none;
  }
  
  .breadcrumb a:hover {
    text-decoration: underline;
  }
  
  .breadcrumb span.separator {
    color: #8B0000;
    margin: 0 10px;
    
  }
  
  .breadcrumb img {
    height: 30px;
    width: 30px;
    margin-left: 10px;
    margin-right: 10px;
  }
  
  .breadcrumb span.separator:before {
    content: "";
    position: absolute;
    top: 50%;
    left: -5px;
    border-top: 5px solid transparent;
    border-bottom: 5px solid transparent;
    border-right: 5px solid #999;
    transform: translateY(-50%);
  }
  
  .breadcrumb span:first-child {
    font-weight: bold;
  }



  @keyframes slideTop{
    0%{
        transform: translateY(-100px);
        opacity: 0;
    }
    100%{
        transform: translateY(0);
        opacity: 1;
    }
  }
  
          img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]
        {display:none !important;}
</style>
<body>
    <div class="container">
    <div class="breadcrumb">
            <a href="javascript:history.back()" class="zoom-effect"><img src='arrow-back-regular-24.png' alt="" title="Go Back"></a> 
            <a href="../profilRH.php" class="zoom-effect"><img src="home-regular-24.png" alt="" title="Profile"></a> 

            </div>
            <div class="submit-form">
            <h4 class="third-text">Send a confirmation email</h4>
            <form class="" id="" name="" enctype="multipart/form-data" method="post" onsubmit="sendEmail(); reset(); return false;">
                <div class="input-box">
                    <input id="name" type="text" class="input" required>
                    <label readonly for="">Candidate name *</label>
                </div>
                <div class="input-box">
                    <input type="email" id= "email" class="input" required >
                    <label for="">Condidate email *</label>
                </div>
                <div class="input-none-changeable">
                    <input type="tel" id="subject" class="input" required readonly>
                    <label readonly for="">SUBJECT: INTERVIEW INVITATION FROM A1ST SERVICES</label>
                </div>
                <div class="input-box">
                    <textarea name="" class="input" required id="message" cols="30" rows="10"></textarea>
                    <label for="">Formulate your Email *</label>
                </div>
                <input type="submit" class="btn" value="SEND">
            </form>
            </div>
            
        </div>

    </div>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script>
function sendEmail() {
  var message = document.getElementById('message').value.replace(/\n/g, '<br>');
  Email.send({
    Host: 'smtp.elasticemail.com',
    Username: 'hr.a1st.service@gmail.com',
    Password: '555646E415E0917F976146CA328AF40A56C0',
    From: 'hr.a1st.service@gmail.com',
    To: document.getElementById('email').value,
    Subject: 'INTERVIEW INVITATION FROM A1ST SERVICES',
    Body: message
  }).then(function(message) {
   
    alert('Email was sent, You will be redirected to the recruitment page.');
      
    
    window.location.href = "recrutement.php";
  });
}
</script>

</body>
</html>

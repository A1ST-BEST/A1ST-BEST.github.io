<?php
    require_once ('connexiondb.php');
    
    if (isset($_POST['email']))
        
        $email = $_POST['email'];
    
    else
        
        $email = "";

    $requete1 = "select * from employes where email='$email'";
    
    $resultat1 = $pdo->query($requete1);

    if ($employes = $resultat1->fetch()) {
        $id = $employes['idemp'];
        $mt = "0000";
        $requete = "update employes set motdepasse=? where idemp=?";
        $param = array($mt,$id);
        $resultat = $pdo->prepare($requete);
        $resultat->execute($param);

        $to = $employes['email'];
        
        $subject = "PASSWORD INITIALIZATION ";
        
        $txt = "New Password :$mt";

        
        header("Location: sendEmail.php");
        exit(); 
        $headers = "From: A1STSERVICES" . "\r\n" . "CC: rh.a1st.service@gmail.com";
        mail($to, $subject, $txt, $headers);?>
        
        
         <html>
            
     <body>
     
     </body></html>

 <?php }

else { ?>
     <html>
     <body>
     
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        swal({
          icon: "warning",
          title: "Error !",
          text: "Email is incorrect!",
          showConfirmButton: true,
          confirmButtonText: "Cerrar",
          closeOnConfirm: false
         }). then(function(result){
            window.location = "motDepasseoublie.php";
             })
         </script>  
         
         <script src="https://smtpjs.com/v3/smtp.js"></script>

     </body></html>
 <?php } 


?>     








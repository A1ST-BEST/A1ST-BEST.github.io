<?php
 require_once("identifier.php");
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Abderrahman Youabd">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Profile</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/navbar-static/">
    
    

    <!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      
  <!--profile-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">

<body>
  <?php include('menuEmployes.php');?>
  <br>
  <div class="container">
    <form class="" id="" name="" method="post" action="modifierinfoemployes.php">
      <div class="row d-flex justify-content-center" style="margin-top:-30px">
        <div class="col-md-10 mt-5 pt-5">
          <div class="row z-depth-3">
            <div class="col-sm-4 bg-dark1 rounded-left" style="color:green">
              <div class="card-block text-center text-white">
                <!--<i class="fas fa-user-tie fa-7x mt-5"></i>-->
                <img style="width:110px;height:110px;border-radius:500px;margin-top:5px;" src="../images/<?php echo $_SESSION['user']['photo'];?>"/>
                <h3 class="card-title"><?php echo $_SESSION['user']['nom'];?></h3>
  <p class="card-text"><?php echo $_SESSION['user']['poste'];?></p><i class="far fa-edit fa-2x mb-4"></i>
              </div>
            </div>
            <div class="col-sm-8 bg-white rounded-right">
              <h3 class="mt-3 text-center">Information</h3>
              <hr class="bg-primary mt-0 w-25">
              <div class="row">
                <div class="col-sm-6 nom">
                  <p class="font-weight-bold">Full Name:</p>
                  <h6 class="text-muted"><?php echo $_SESSION['user']['nom'];?></h6>
                </div>
                <div class="col-sm-6 prenom">
                  <p class="font-weight-bold">Phone Number:</p>
                  <h6 class="text-muted"><?php echo $_SESSION['user']['telephone'];?></h6>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-12">
                  <p class="font-weight-bold">Email:</p>
                  <h6 class=" text-muted"><?php echo $_SESSION['user']['email'];?></h6>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-6">
                  <p class="font-weight-bold">Department</p>
                  <h6 class="text-muted"><?php echo $_SESSION['user']['departement'];?></h6>
                </div>
                <div class="col-sm-6">
                  <p class="font-weight-bold">Function</p>
                  <h6 class="text-muted"><?php echo $_SESSION['user']['poste'];?></h6>
                </div>
              </div>
              <hr class="bg-primary">
              <ul class="list-unstyled d-flex justify-content-center mt-4">
                <input type="submit" style="background-color:#351E10;color:white;border-radius: 10px;" value="Edit my details">
              </ul>  
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
  </body>
  
  <style>
.z-depth-3 {
  width: 600px; /* fixed width for larger screens */
  box-shadow: 0 2px 5px 0 #4B382A, 0 2px 10px 0 #4B382A;
  
}

@media only screen and (max-width: 768px) {
  .z-depth-3 {
    width: auto; /* remove fixed width on smaller screens */
  }
}

html, body{
  background: url('../images/Wood.jpeg');
  background-size: cover;
}

.list-unstyled:hover{
  transform: scale(1.029);
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:ital@1&display=swap');



  p, a, span, h1, label, .form-group, .list-unstyled, h2, h3, h4, h6{
      font-family: 'Poppins', sans-serif !important;
    }





  </style>
</html>





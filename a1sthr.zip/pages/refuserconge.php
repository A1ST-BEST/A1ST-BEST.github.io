<?php
   session_start();
  if (isset($_SESSION['user'])){
  require_once("connexiondb.php");
    if (isset($_GET['idemp']))
        
        $id = $_GET['idemp'];
    
    else
        
        $id = "";

    $requete1 = "select * from employes where idemp='$id'";
    
    $resultat1 = $pdo->query($requete1);

    if ($employes = $resultat1->fetch()) {
        $email = $employes['email'];
        
        $to = $employes['email'];
        
        $subject = "RESPONSE TO THE LEAVE REQUEST ";
        
        $txt = "your leave request has been refused.";
        
        $headers = "From: A1STSERVICES" . "\r\n" . "CC: rh.a1st.service@gmail.com";
        
        mail($to, $subject, $txt, $headers);
    }
      
    $requete2="delete from congesdemandes where idemp=$id";
   $resultat2=$pdo->prepare($requete2);
   $resultat2->execute();

   }
?>
<html>
     <body>
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        swal({
          icon: "success",
          title: "well done !",
          text: "The leave has been successfully deleted!",
          showConfirmButton: true,
          confirmButtonText: "Cerrar",
          closeOnConfirm: false
         }). then(function(result){
            window.location = "congesdemandes.php";
             })
         </script>     
     </body></html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Abderrahman Youabd">
    <title>Document</title>
</head>
<body>   
        <footer>
          <div class="footer-container">
            <p>&copy; 2023 Abderrahman Youabd. All rights reserved.</p>
            <p>Xx Kassai ut. Debrecen, Hungary 40XX</p>
          </div>
        </footer>
      
    
</body>


<style>

body {
  display: flex;
  flex-direction: column;
}

main {
  flex-grow: 1;
}

footer {
  width: 100%;
  position: fixed;
  bottom: 0;
  left: 0;
  background-color: #333;
  color: #fff;
  padding: 20px;
  text-align: center;
}
.footer-container {

  text-align: center;
  font-size: 14px;
}

@media only screen and (max-width: 600px) {
  .footer-container {
    flex-direction: column;
  }
}




</style>

</html>
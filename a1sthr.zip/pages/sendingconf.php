<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Abderrahman Youabd">
    <title>Invitation email</title>
    <link rel="stylesheet" href="../pages/stylesendingconf.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
      </script>
</head>
<body>
    <div class="container">
    <div class="breadcrumb">
            <a href="javascript:history.back()" class="zoom-effect"><img src='../icons/arrow-back-regular-24.png' alt="" title="Go Back"></a> 
            <a href="../pages/profilRH.php" class="zoom-effect"><img src="../icons/home-regular-24.png" alt="" title="Profile"></a> 

            </div>
            <div class="submit-form">
            <h4 class="third-text">Send a confirmation email</h4>
            <form class="" id="" name="" enctype="multipart/form-data" method="post" onsubmit="sendEmail(); reset(); return false;">
                <div class="input-box">
                    <input id="name" type="text" class="input" required>
                    <label readonly for="">Candidate name *</label>
                </div>
                <div class="input-box">
                    <input type="email" id= "email" class="input" required >
                    <label for="">Condidate email *</label>
                </div>
                <div class="input-none-changeable">
                    <input type="tel" id="subject" class="input" required readonly>
                    <label readonly for="">SUBJECT: INTERVIEW INVITATION FROM A1ST SERVICES</label>
                </div>
                <div class="input-box">
                    <textarea name="" class="input" required id="message" cols="30" rows="10"></textarea>
                    <label for="">Formulate your Email *</label>
                </div>
                <input type="submit" class="btn" value="SEND">
            </form>
            </div>
            
        </div>

    </div>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script>
function sendEmail() {
  var message = document.getElementById('message').value.replace(/\n/g, '<br>');
  Email.send({
    Host: 'smtp.elasticemail.com',
    Username: 'hr.a1st.service@gmail.com',
    Password: '555646E415E0917F976146CA328AF40A56C0',
    From: 'hr.a1st.service@gmail.com',
    To: document.getElementById('email').value,
    Subject: 'INTERVIEW INVITATION FROM A1ST SERVICES',
    Body: message
  }).then(function(message) {
   
    alert('Email was sent, You will be redirected to the recruitment page.');
      
    
    window.location.href = "recrutement.php";
  });
}
</script>

</body>
</html>

<?php
   //with the pdo object we can connect to any type of database (mysql, sqlserver...)
   //to create a new object of the pdo class, you must specify the server, the database, the user name and the password
   try{
      $pdo= new PDO ("mysql:host=localhost;dbname=rh","root","");
   }catch(Exception $e){
      die('Connexion error :'.$e->getMessage());
   }

  
	


   
?> 
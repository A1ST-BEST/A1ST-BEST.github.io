<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" author="Abderrahman Youabd" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Modify Employee</title>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-pG/+zofxIsNJ+slrvrpaAq25dZrXQ73O/KPHvi+JqnfoG/5yBJInI21z+o27P8mF" crossorigin="anonymous">

  <!-- Custom CSS -->
  <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital@1&display=swap');



p, a, span, h1, h4, label, .form-group, button, h5, h6, h2, h3, .form-control{
    font-family: 'Poppins', sans-serif !important;
  }

    .inscform {
      margin: auto;
      max-width: 500px;
      padding: 30px;
      background-color: white;
      padding: 40px;
      border-radius: 20px;
    }

    html, body {
      background: url('../images/Wood.jpeg');
      background-size: cover;
    }

    .btn-success{
      background: #402F1D !important;
    }

    .btn-success:hover{
      transform: scale(1.029);
    }
    .form-control{
        margin-right: 100px !important;
        margin-bottom: 10px !important;
      }

  </style>
</head>
<body>
  <?php include('menuEmployes.php');?>
    
  <div class="container">
    <div class="inscform">
      <form class="" id="" name="" method="post" action="modificationinfoemployes.php">
        <div class="form-group">
          <label>Email</label>
          <input type="hidden" name="id" class="form-control" placeholder="id" value="<?php echo $_SESSION['user']['idemp'];?>">
          <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo $_SESSION['user']['email'];?>">
        </div>
        <div class="form-group"> 
             <label>Date of birth</label>
            <input type="date" name="date" class="form-control" placeholder="Date of birth" value="<?php echo $_SESSION['user']['dateNaissance'];?>">      
         </div>
         <div class="form-group">
              <label>Full Name</label>
            <input type="text" name="nom" class="form-control" placeholder="Name" value="<?php echo $_SESSION['user']['nom'];?>">   
         </div>
         <div class="form-group">
             <label>Phone Number</label>
            <input type="number" name="telephone" class="form-control" placeholder="Phone" value="<?php echo $_SESSION['user']['telephone'];?>">   
         </div>
         <div class="form-group">
              <label>Department</label>
            <input type="text" name="dep" class="form-control" placeholder="Department" value="<?php echo $_SESSION['user']['departement'];?>">   
         </div>
         <div class="form-group">
             <label>Position</label>
            <input type="text" name="poste" class="form-control" placeholder="Position" value="<?php echo $_SESSION['user']['poste'];?>">   
         </div>
         <div class="form-group">
              <label>Password</label>
            <input type="password" name="mt" class="form-control" placeholder="Password" value="<?php echo $_SESSION['user']['motdepasse'];?>">   
         </div>
        <br>     
        <div class="form-group">
          <input style="width: 100%;text-align: center;" type="submit" class="btn btn-success" value="Edit">
        </div>    
      </form> 
    </div>      
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
</body>
</html>
<!--la page index aide a lancer la premier page qu'on a spécifier comme page de démarrage de l'application dans notre cas accueil.php 
une fois en tape le chemin localhost le serveur nous dirigeons vers cette page -->
<?php 
header("location:pages/accueil.php")
?>